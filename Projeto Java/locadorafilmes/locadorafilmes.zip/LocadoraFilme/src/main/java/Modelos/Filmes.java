package Modelos;


public class Filmes {

	public int idFilme;
	public String NomeFilme;
	public int AnoFilme;
	public String Genero;

	public int getIdFilme() {
		return idFilme;
	}

	public void setIdFilme(int idFilme) {
		this.idFilme = idFilme;
	}
	
	public String getNomeFilme() {
		return NomeFilme;
	}
	
	public void setNomeFilme(String nomeFilme) {
		NomeFilme = nomeFilme;
	}
	
	public int getAnoFilme() {
		return AnoFilme;
	}
	
	public void setAnoFilme(int anoFilme) {
		AnoFilme = anoFilme;
	}
	
	public String getGenero() {
		return Genero;
	}
	
	public void setGenero(String genero) {
		Genero = genero;
	}


}
